dealer_code = None

''' FACEBOOK LOGIN CREDENTIALS '''
fb_user_access_token = 'EAACEdEose0cBADl8qWLo1PALGFbzHurAPrXNz97pBiPX8aIQxaO2EPCGbartv8VieQZCrY5c4O9IACCEbuvy0CbLQiHWuJNQYnCVlr2bSALheOt2Qjw9c1zuAqHaSFmBf6htwEzZAiDVDAypn4ZAyZALPEK9dZAB9YOuAxDgVI0nX8Kk3RQZAqRdoCBSZCN7EptlGSEruTx3wZDZD'
fb_page_access_token = 'EAACEdEose0cBAIebWohVmAQJItWWeOk8NutYK3vwNfUWZCATsv7WHR3YZBE6kA0gN5u99yitKy8j8qvsJRWK8bMyO76rq7d1ZBGKBjnNAJnSX8owooIq5l6xvV67KaXQmssvlMerUUgMtgaOtsWy4ZCP3eIzNDx04V6NH1aeBGcGArq1Nh9WE4oR1aA8Hx0uwxIPdRgdjAZDZD'
FB_APP_SECRET = '6392b22a3eda9770c0d9960769edc752'
FB_APP_ID = '323689698142176'
fb_dealer_id = '140202782671268'

''' TWITTER LOGIN CREDENTIALS '''
twitter_consumer_key = 'itXZtlNl0MNnvjKEq4qzknIGp'
twitter_consumer_secret = '8JQKq4Jk6H9ZfIzkIOINBeWd4esrRk4Sw5ofqKUp79DbQ2Jxz2'
twitter_access_token = '25510198-JaFz3N1dAsgzwc75mbMYVGTpLNZ0CrZw00ZixLy6y'
twitter_access_token_secret = 'iva8xNnTuYo9xTGKP2BkALNhQo0aK9bj2ZNMZloEeODPp'
twitter_user_id = '25510198'

''' INSTAGRAM LOGIN CREDENTIALS '''
instagram_username = 'tustintoyotaca'
instagram_password = '123tustin'

''' YELP LOGIN CREDENTIALS '''
yelp_username = 'haleyh@tkmkt.com'
yelp_password = 'Tksimple1'
yelp_client_id = 'AikEMEl5jKqMT_867TQc_w'
yelp_client_secret = 'ziplKq8xq0L6ZQmJQjKaMRVLge0MaDqWPcrtpnhQheIND3Zmoqqhr1znf5z8kQvB'

''' FTP LOGIN CREDENTIALS '''
ftp_username = 'tkmktdevftp@tkmkt-dev.com'
ftp_password = 'c0FF33dev'
ftp_url = 'ftp.tkmkt-dev.com'
# ftp_username = 'williamgardner'
# ftp_password = 'k34xGnm@e78gMf'
# ftp_url = 'ftp.williamjohngardner.com'

#ssh -i .ssh/billssshkey.pem ec2-user@35.160.106.170
